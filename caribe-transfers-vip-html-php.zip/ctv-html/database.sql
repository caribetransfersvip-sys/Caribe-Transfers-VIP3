-- =========================================================================
-- Caribe Transfers VIP — MySQL schema (Hostinger-compatible)
-- Import via hPanel > phpMyAdmin, or: mysql -u USER -p DBNAME < database.sql
-- =========================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- admin_users — staff accounts (replaces Supabase auth.users + profiles)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('super_admin','administrator','manager','driver') NOT NULL DEFAULT 'manager',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- clients
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(40),
  is_vip TINYINT(1) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_clients_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- drivers
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS drivers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_user_id INT UNSIGNED NULL,
  full_name VARCHAR(150) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  license_number VARCHAR(60) NOT NULL,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  rating DECIMAL(2,1) NOT NULL DEFAULT 5.0,
  assigned_vehicle_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_user_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- vehicles
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vehicles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  type ENUM('economy','suv','luxury','family','van') NOT NULL,
  plate_number VARCHAR(30) NOT NULL UNIQUE,
  capacity_passengers TINYINT UNSIGNED NOT NULL DEFAULT 4,
  capacity_luggage TINYINT UNSIGNED NOT NULL DEFAULT 4,
  status ENUM('available','in_use','maintenance','out_of_service') NOT NULL DEFAULT 'available',
  insurance_expiry DATE,
  next_maintenance DATE,
  image_url VARCHAR(255),
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE drivers
  ADD CONSTRAINT fk_drivers_vehicle FOREIGN KEY (assigned_vehicle_id)
  REFERENCES vehicles(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------
-- routes & pricing
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS routes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  origin VARCHAR(150) NOT NULL,
  destination VARCHAR(150) NOT NULL,
  distance_km DECIMAL(6,2),
  estimated_minutes SMALLINT UNSIGNED,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pricing (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  route_id INT UNSIGNED,
  vehicle_type ENUM('economy','suv','luxury','family','van') NOT NULL,
  base_price DECIMAL(10,2) NOT NULL,
  price_per_extra_passenger DECIMAL(10,2) NOT NULL DEFAULT 0,
  currency VARCHAR(3) NOT NULL DEFAULT 'USD',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- reservations
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reservations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(20) NOT NULL UNIQUE,
  client_id INT UNSIGNED,
  driver_id INT UNSIGNED NULL,
  vehicle_id INT UNSIGNED NULL,
  service_type ENUM('airport_transfer','private_transportation','vip_chauffeur','corporate_transportation','accommodation_assistance','vehicle_rental_assistance','tourism_excursion') NOT NULL,
  pickup_location VARCHAR(200) NOT NULL,
  destination VARCHAR(200) NOT NULL,
  airport_code VARCHAR(10),
  pickup_date DATE NOT NULL,
  pickup_time TIME NOT NULL,
  passengers TINYINT UNSIGNED NOT NULL DEFAULT 1,
  luggage TINYINT UNSIGNED NOT NULL DEFAULT 0,
  vehicle_type ENUM('economy','suv','luxury','family','van') NOT NULL,
  is_round_trip TINYINT(1) NOT NULL DEFAULT 0,
  return_date DATE NULL,
  return_time TIME NULL,
  payment_method ENUM('cash','card','bank_transfer','stripe','paypal') NOT NULL DEFAULT 'cash',
  special_requests TEXT,
  status ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
  price DECIMAL(10,2),
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
  FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE SET NULL,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
  INDEX idx_reservations_status (status),
  INDEX idx_reservations_date (pickup_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- payments
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT UNSIGNED,
  amount DECIMAL(10,2) NOT NULL,
  method ENUM('cash','card','bank_transfer','stripe','paypal') NOT NULL,
  status ENUM('pending','paid','refunded','failed') NOT NULL DEFAULT 'pending',
  transaction_ref VARCHAR(120),
  refunded_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------
-- testimonials, gallery, settings, notifications, activity_logs,
-- contact_messages
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS testimonials (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(150) NOT NULL,
  content TEXT NOT NULL,
  rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS gallery (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150),
  image_url VARCHAR(255) NOT NULL,
  category VARCHAR(60),
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  `key` VARCHAR(100) PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_user_id INT UNSIGNED,
  title VARCHAR(200) NOT NULL,
  body TEXT,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_user_id) REFERENCES admin_users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id INT UNSIGNED NULL,
  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(60),
  entity_id INT UNSIGNED,
  metadata TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (actor_id) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Seed data
-- ---------------------------------------------------------------------
INSERT INTO settings (`key`, value) VALUES
  ('site_config', '{"whatsapp":"+1 849-390-2963","support_email":"support@caribetransfersvip.com"}')
ON DUPLICATE KEY UPDATE value = VALUES(value);

-- First admin user: do NOT hardcode a password hash here. After importing
-- this schema, create your first admin account by running the one-time
-- script admin/create-admin.php (see README.md), which generates a real
-- bcrypt hash with PHP's password_hash() and inserts it safely.
