<?php
/**
 * booking.php — handles the public reservation form submitted from
 * booking.html (js/booking.js). Validates + sanitizes input, checks
 * CSRF, upserts the client, inserts the reservation, and emails both
 * the customer and support@caribetransfersvip.com.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/rate_limit.php';
require_once __DIR__ . '/includes/mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Method not allowed'], 405);
}

if (!rate_limit_check('booking', 8, 300)) {
    json_response(['success' => false, 'message' => 'Too many requests. Please try again shortly.'], 429);
}

if (!csrf_validate($_POST['csrf_token'] ?? '')) {
    json_response(['success' => false, 'message' => 'Invalid or expired form session. Please refresh and try again.'], 403);
}

// ---- Validate + sanitize every field (prepared statements handle the
// SQL-injection layer; this layer guards data shape / XSS on redisplay). --
$errors = [];

$serviceTypes = ['airport_transfer', 'private_transportation', 'vip_chauffeur', 'corporate_transportation', 'accommodation_assistance', 'vehicle_rental_assistance', 'tourism_excursion'];
$vehicleTypes = ['economy', 'suv', 'luxury', 'family', 'van'];
$paymentMethods = ['cash', 'card', 'bank_transfer', 'stripe', 'paypal'];

$service_type = $_POST['service_type'] ?? '';
if (!in_array($service_type, $serviceTypes, true)) $errors[] = 'Invalid service type';

$full_name = clean_input($_POST['full_name'] ?? '');
if (mb_strlen($full_name) < 2) $errors[] = 'Full name is required';

$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
if (!$email) $errors[] = 'A valid email is required';

$phone = clean_input($_POST['phone'] ?? '');
if (mb_strlen(preg_replace('/\D/', '', $phone)) < 7) $errors[] = 'A valid phone number is required';

$pickup_location = clean_input($_POST['pickup_location'] ?? '');
$destination = clean_input($_POST['destination'] ?? '');
if (mb_strlen($pickup_location) < 2 || mb_strlen($destination) < 2) $errors[] = 'Pickup and destination are required';

$pickup_date = $_POST['pickup_date'] ?? '';
$pickup_time = $_POST['pickup_time'] ?? '';
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $pickup_date)) $errors[] = 'Invalid date';
if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $pickup_time)) $errors[] = 'Invalid time';

$passengers = filter_var($_POST['passengers'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 20]]);
$luggage = filter_var($_POST['luggage'] ?? 0, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 20]]);
if ($passengers === false) $errors[] = 'Invalid passenger count';
if ($luggage === false) $luggage = 0;

$vehicle_type = $_POST['vehicle_type'] ?? '';
if (!in_array($vehicle_type, $vehicleTypes, true)) $errors[] = 'Invalid vehicle type';

$payment_method = $_POST['payment_method'] ?? 'cash';
if (!in_array($payment_method, $paymentMethods, true)) $payment_method = 'cash';

$is_round_trip = !empty($_POST['is_round_trip']);
$return_date = $is_round_trip ? ($_POST['return_date'] ?? null) : null;
$return_time = $is_round_trip ? ($_POST['return_time'] ?? null) : null;
if ($is_round_trip && (!$return_date || !$return_time)) {
    $errors[] = 'Return date and time are required for round trips';
}

$special_requests = clean_input($_POST['special_requests'] ?? '');
if (mb_strlen($special_requests) > 1000) $special_requests = mb_substr($special_requests, 0, 1000);

if (!empty($errors)) {
    json_response(['success' => false, 'message' => implode(' ', $errors)], 400);
}

// ---- Persist ------------------------------------------------------------
try {
    $pdo = db();
    $pdo->beginTransaction();

    // Find or create the client by email.
    $stmt = $pdo->prepare('SELECT id FROM clients WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    $client = $stmt->fetch();

    if ($client) {
        $clientId = $client['id'];
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO clients (full_name, email, phone, created_at) VALUES (:name, :email, :phone, NOW())'
        );
        $stmt->execute(['name' => $full_name, 'email' => $email, 'phone' => $phone]);
        $clientId = (int) $pdo->lastInsertId();
    }

    $bookingRef = generate_booking_ref();

    $stmt = $pdo->prepare('
        INSERT INTO reservations (
            booking_ref, client_id, service_type, pickup_location, destination,
            pickup_date, pickup_time, passengers, luggage, vehicle_type,
            is_round_trip, return_date, return_time, payment_method,
            special_requests, status, created_at
        ) VALUES (
            :ref, :client_id, :service_type, :pickup, :destination,
            :pdate, :ptime, :passengers, :luggage, :vehicle,
            :round_trip, :rdate, :rtime, :payment,
            :requests, "pending", NOW()
        )
    ');
    $stmt->execute([
        'ref' => $bookingRef,
        'client_id' => $clientId,
        'service_type' => $service_type,
        'pickup' => $pickup_location,
        'destination' => $destination,
        'pdate' => $pickup_date,
        'ptime' => $pickup_time,
        'passengers' => $passengers,
        'luggage' => $luggage,
        'vehicle' => $vehicle_type,
        'round_trip' => $is_round_trip ? 1 : 0,
        'rdate' => $return_date,
        'rtime' => $return_time,
        'payment' => $payment_method,
        'requests' => $special_requests,
    ]);

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Booking insert failed: ' . $e->getMessage());
    json_response(['success' => false, 'message' => 'Could not save your reservation. Please try again.'], 500);
}

// ---- Notify (best-effort; failure here should not fail the booking) -----
send_email(
    $email,
    'Your Caribe Transfers VIP reservation request — ' . $bookingRef,
    "<p>Hi " . htmlspecialchars($full_name) . ",</p>
     <p>We've received your reservation request <strong>{$bookingRef}</strong> and will confirm it shortly.</p>
     <p><strong>Route:</strong> {$pickup_location} &rarr; {$destination}<br>
        <strong>Date:</strong> {$pickup_date} {$pickup_time}</p>
     <p>Questions? Reply to this email or WhatsApp us at +1 849-390-2963.</p>"
);

send_email(
    SUPPORT_EMAIL,
    'New reservation request — ' . $bookingRef,
    "<p>New booking from " . htmlspecialchars($full_name) . " ({$email}, {$phone}).</p>
     <p>{$service_type} — {$pickup_location} &rarr; {$destination} on {$pickup_date} {$pickup_time}.</p>"
);

json_response(['success' => true, 'booking_ref' => $bookingRef], 201);
