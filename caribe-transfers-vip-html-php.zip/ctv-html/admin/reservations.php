<?php
/**
 * admin/reservations.php — Reservations management. Table listing wired to MySQL;
 * follow admin/dashboard.php's pattern to add search, pagination and
 * Create/Edit/Delete actions (POST handlers with CSRF + prepared statements,
 * same as booking.php).
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';

$admin = require_admin();
$rows = db()->query('SELECT * FROM reservations ORDER BY 1 DESC LIMIT 50')->fetchAll();
$columns = $rows ? array_keys($rows[0]) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reservations | Caribe Transfers VIP Admin</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="icon" href="../assets/images/logo.png">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
  <div class="admin-shell">
    <aside class="admin-sidebar">
      <div class="admin-brand">
        <img src="../assets/images/logo.png" alt="CTV" width="36" height="36">
        <span style="font-family:var(--font-display);font-weight:700;font-size:0.85rem;">CTV ADMIN</span>
      </div>
      <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="reservations.php" class="is-active">Reservations</a>
        <a href="clients.php">Clients</a>
        <a href="drivers.php">Drivers</a>
        <a href="vehicles.php">Vehicles</a>
        <a href="payments.php">Payments</a>
        <a href="reports.php">Reports</a>
        <a href="settings.php">Settings</a>
      </nav>
      <form method="post" action="logout.php">
        <button type="submit" class="admin-logout">Logout (<?= htmlspecialchars($admin['name']) ?>)</button>
      </form>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:var(--font-display);font-size:1.6rem;font-weight:800;">Reservations</h1>
      <p style="color:var(--text-faint);margin-top:0.25rem;"><?= count($rows) ?> records</p>

      <table class="admin-table">
        <thead><tr>
          <?php foreach ($columns as $col): ?><th><?= htmlspecialchars($col) ?></th><?php endforeach; ?>
        </tr></thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="<?= max(count($columns),1) ?>" style="text-align:center;color:var(--text-faint);padding:2.5rem;">No records yet.</td></tr>
          <?php else: foreach ($rows as $row): ?>
            <tr>
              <?php foreach ($row as $val): ?><td><?= htmlspecialchars((string) $val) ?></td><?php endforeach; ?>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </main>
  </div>
</body>
</html>
