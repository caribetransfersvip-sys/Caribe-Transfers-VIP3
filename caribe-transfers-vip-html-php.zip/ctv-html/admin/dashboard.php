<?php
/**
 * admin/dashboard.php — overview widgets + recent reservations table.
 * Protected by require_admin() (session + role check via includes/auth.php).
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';

$admin = require_admin();
$pdo = db();

$today = date('Y-m-d');
$todayCount = $pdo->query("SELECT COUNT(*) FROM reservations WHERE pickup_date = '$today'")->fetchColumn();
$pendingCount = $pdo->query("SELECT COUNT(*) FROM reservations WHERE status = 'pending'")->fetchColumn();
$vehicleCount = $pdo->query("SELECT COUNT(*) FROM vehicles WHERE status = 'available'")->fetchColumn();
$driverCount = $pdo->query("SELECT COUNT(*) FROM drivers WHERE is_available = 1")->fetchColumn();

$stmt = $pdo->query('SELECT * FROM reservations ORDER BY created_at DESC LIMIT 20');
$reservations = $stmt->fetchAll();

$statusClass = [
    'pending' => 'status-pending',
    'confirmed' => 'status-confirmed',
    'completed' => 'status-completed',
    'cancelled' => 'status-cancelled',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard | Caribe Transfers VIP Admin</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="icon" href="../assets/images/logo.png">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
  <div class="admin-shell">
    <aside class="admin-sidebar">
      <div class="admin-brand">
        <img src="../assets/images/logo.png" alt="CTV" width="36" height="36">
        <span style="font-family:var(--font-display);font-weight:700;font-size:0.85rem;">CTV ADMIN</span>
      </div>
      <nav class="admin-nav">
        <a href="dashboard.php" class="is-active">Dashboard</a>
        <a href="reservations.php">Reservations</a>
        <a href="clients.php">Clients</a>
        <a href="drivers.php">Drivers</a>
        <a href="vehicles.php">Vehicles</a>
        <a href="payments.php">Payments</a>
        <a href="reports.php">Reports</a>
        <a href="settings.php">Settings</a>
      </nav>
      <form method="post" action="logout.php">
        <button type="submit" class="admin-logout">Logout (<?= htmlspecialchars($admin['name']) ?>)</button>
      </form>
    </aside>

    <main class="admin-main">
      <h1 style="font-family:var(--font-display);font-size:1.6rem;font-weight:800;">Dashboard</h1>
      <p style="color:var(--text-faint);margin-top:0.25rem;">Overview of today's operations.</p>

      <div class="stat-grid">
        <div class="stat-card">
          <div class="stat-label"><span>Today's Reservations</span></div>
          <div class="stat-value"><?= (int) $todayCount ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label"><span>Pending Requests</span></div>
          <div class="stat-value"><?= (int) $pendingCount ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label"><span>Vehicles Available</span></div>
          <div class="stat-value"><?= (int) $vehicleCount ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label"><span>Drivers Online</span></div>
          <div class="stat-value"><?= (int) $driverCount ?></div>
        </div>
      </div>

      <table class="admin-table">
        <thead>
          <tr>
            <th>Booking Ref</th><th>Service</th><th>Route</th><th>Date</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($reservations)): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--text-faint);padding:2.5rem;">No reservations yet.</td></tr>
          <?php else: foreach ($reservations as $r): ?>
            <tr>
              <td><strong><?= htmlspecialchars($r['booking_ref']) ?></strong></td>
              <td><?= htmlspecialchars(str_replace('_', ' ', $r['service_type'])) ?></td>
              <td><?= htmlspecialchars($r['pickup_location']) ?> &rarr; <?= htmlspecialchars($r['destination']) ?></td>
              <td><?= htmlspecialchars($r['pickup_date']) ?> <?= htmlspecialchars($r['pickup_time']) ?></td>
              <td><span class="status-pill <?= $statusClass[$r['status']] ?? '' ?>"><?= htmlspecialchars($r['status']) ?></span></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </main>
  </div>
</body>
</html>
