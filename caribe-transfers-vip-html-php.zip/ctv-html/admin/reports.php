<?php
/**
 * admin/reports.php — revenue/reservation charting skeleton. The queries
 * below aggregate real data; wire a small JS chart (e.g. Chart.js from a
 * CDN) against the $daily array to render the actual graphs.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';

$admin = require_admin();
$daily = db()->query(
    "SELECT pickup_date, COUNT(*) AS total FROM reservations
     WHERE pickup_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY pickup_date ORDER BY pickup_date"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports | Caribe Transfers VIP Admin</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="icon" href="../assets/images/logo.png">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
  <div class="admin-shell">
    <aside class="admin-sidebar">
      <div class="admin-brand"><img src="../assets/images/logo.png" width="36" height="36" alt="CTV"><span style="font-family:var(--font-display);font-weight:700;font-size:0.85rem;">CTV ADMIN</span></div>
      <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="reservations.php">Reservations</a>
        <a href="clients.php">Clients</a>
        <a href="drivers.php">Drivers</a>
        <a href="vehicles.php">Vehicles</a>
        <a href="payments.php">Payments</a>
        <a href="reports.php" class="is-active">Reports</a>
        <a href="settings.php">Settings</a>
      </nav>
      <form method="post" action="logout.php"><button type="submit" class="admin-logout">Logout (<?= htmlspecialchars($admin['name']) ?>)</button></form>
    </aside>
    <main class="admin-main">
      <h1 style="font-family:var(--font-display);font-size:1.6rem;font-weight:800;">Reports</h1>
      <p style="color:var(--text-faint);margin-top:0.25rem;">Reservations per day, last 30 days.</p>
      <table class="admin-table">
        <thead><tr><th>Date</th><th>Reservations</th></tr></thead>
        <tbody>
          <?php if (empty($daily)): ?>
            <tr><td colspan="2" style="text-align:center;color:var(--text-faint);padding:2.5rem;">No data yet.</td></tr>
          <?php else: foreach ($daily as $d): ?>
            <tr><td><?= htmlspecialchars($d['pickup_date']) ?></td><td><?= (int) $d['total'] ?></td></tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </main>
  </div>
</body>
</html>
