<?php
/**
 * admin/create-admin.php — ONE-TIME setup script to create your first
 * admin account with a properly generated password hash.
 *
 * Run it once from the command line on your server (SSH, or Hostinger's
 * "Terminal" in hPanel if your plan includes it):
 *
 *   php admin/create-admin.php "Your Name" "you@example.com" "a-strong-password"
 *
 * If your host has no shell access, run this file once through the browser
 * (it accepts the same 3 values as ?name=&email=&password= query params),
 * then DELETE this file immediately afterward — leaving it live is a
 * standing way for anyone to create an admin account.
 */
require_once __DIR__ . '/../config.php';

$isCli = php_sapi_name() === 'cli';

if ($isCli) {
    [$name, $email, $password] = [$argv[1] ?? null, $argv[2] ?? null, $argv[3] ?? null];
} else {
    $name = $_GET['name'] ?? null;
    $email = $_GET['email'] ?? null;
    $password = $_GET['password'] ?? null;
}

if (!$name || !$email || !$password) {
    $msg = "Usage: php create-admin.php \"Full Name\" \"email@example.com\" \"password\"\n";
    if ($isCli) { fwrite(STDERR, $msg); exit(1); }
    header('Content-Type: text/plain');
    echo $msg;
    exit;
}

if (strlen($password) < 8) {
    $msg = "Password must be at least 8 characters.\n";
    if ($isCli) { fwrite(STDERR, $msg); exit(1); }
    header('Content-Type: text/plain');
    echo $msg;
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    $stmt = db()->prepare(
        'INSERT INTO admin_users (full_name, email, password_hash, role, is_active)
         VALUES (:name, :email, :hash, "super_admin", 1)
         ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), full_name = VALUES(full_name)'
    );
    $stmt->execute(['name' => $name, 'email' => $email, 'hash' => $hash]);
    $out = "Admin user created/updated for {$email}. Delete this file now.\n";
} catch (Throwable $e) {
    $out = 'Error: ' . $e->getMessage() . "\n";
}

if ($isCli) { echo $out; } else { header('Content-Type: text/plain'); echo $out; }
