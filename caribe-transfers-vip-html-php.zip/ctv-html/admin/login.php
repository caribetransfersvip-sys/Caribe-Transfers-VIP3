<?php
/**
 * admin/login.php — staff login. Passwords are hashed with password_hash()
 * (bcrypt/argon2 depending on PHP build) and verified with password_verify().
 * Failed attempts are rate-limited per session to slow brute force.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/rate_limit.php';

start_admin_session();

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$timedOut = isset($_GET['timeout']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!rate_limit_check('admin_login', 6, 300)) {
        $error = 'Too many attempts. Please wait a few minutes and try again.';
    } elseif (!csrf_admin_validate($_POST['csrf_token'] ?? '')) {
        $error = 'Your session expired. Please try again.';
    } else {
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            $error = 'Enter a valid email and password.';
        } else {
            $stmt = db()->prepare('SELECT id, full_name, password_hash, role FROM admin_users WHERE email = :email AND is_active = 1 LIMIT 1');
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_name'] = $user['full_name'];
                $_SESSION['admin_role'] = $user['role'];
                $_SESSION['last_activity'] = time();

                // Log the login for the audit trail.
                $log = db()->prepare('INSERT INTO activity_logs (actor_id, action, created_at) VALUES (:id, "admin_login", NOW())');
                $log->execute(['id' => $user['id']]);

                header('Location: dashboard.php');
                exit;
            }

            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Login | Caribe Transfers VIP</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="icon" href="../assets/images/logo.png">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
  <div class="login-shell">
    <div class="login-card">
      <div class="brand">
        <img src="../assets/images/logo.png" alt="Caribe Transfers VIP" width="56" height="56">
        <h1 style="margin-top:1rem;font-size:1.2rem;">Staff Login</h1>
      </div>

      <?php if ($timedOut): ?>
        <p class="alert alert-error" style="margin-top:1.5rem;">Your session timed out. Please sign in again.</p>
      <?php endif; ?>
      <?php if ($error): ?>
        <p class="alert alert-error" style="margin-top:1.5rem;"><?= htmlspecialchars($error) ?></p>
      <?php endif; ?>

      <form method="post" novalidate>
        <?= csrf_admin_field() ?>
        <input type="email" name="email" placeholder="Email" required autocomplete="username">
        <input type="password" name="password" placeholder="Password" required autocomplete="current-password">
        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
      </form>
    </div>
  </div>
</body>
</html>
