#!/usr/bin/env python3
"""
Dev-time helper only — NOT part of the deployed site.
Assembles the shared header/nav/footer/whatsapp markup into each static
HTML page so all five pages stay pixel-identical without hand-copying.
Run: python3 build_pages.py   -> writes index.html, about.html, etc.
"""
import re

NAV_ITEMS = [
    ("index.html#about", "About"),
    ("services.html", "Services"),
    ("booking.html", "Book"),
    ("index.html#testimonials", "Testimonials"),
    ("index.html#gallery", "Gallery"),
    ("index.html#faq", "FAQ"),
    ("contact.html", "Contact"),
]

def nav_links(mobile=False):
    cls = "mobile-nav" if mobile else "nav-links"
    items = "\n".join(
        f'      <a href="{href}">{label}</a>' for href, label in NAV_ITEMS
    )
    return items

def head(title, description, canonical):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
  <meta name="description" content="{description}">
  <link rel="canonical" href="https://caribetransfersvip.com/{canonical}">

  <!-- Open Graph -->
  <meta property="og:title" content="{title}">
  <meta property="og:description" content="{description}">
  <meta property="og:type" content="website">
  <meta property="og:image" content="/assets/images/logo.png">
  <meta property="og:url" content="https://caribetransfersvip.com/{canonical}">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{title}">
  <meta name="twitter:description" content="{description}">

  <link rel="icon" href="assets/images/logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="stylesheet" href="css/animations.css">

  <script type="application/ld+json">
  {{
    "@context": "https://schema.org",
    "@type": "TransportationCompany",
    "name": "Caribe Transfers VIP",
    "image": "https://caribetransfersvip.com/assets/images/logo.png",
    "email": "support@caribetransfersvip.com",
    "telephone": "+18493902963",
    "areaServed": "Dominican Republic",
    "url": "https://caribetransfersvip.com/"
  }}
  </script>
</head>
"""

def header_html():
    return f"""  <header class="site-header">
    <div class="container">
      <a href="index.html" class="brand">
        <img src="assets/images/logo.png" alt="Caribe Transfers VIP logo" width="42" height="42">
        <span class="brand-name">CARIBE TRANSFERS <span>VIP</span></span>
      </a>

      <nav class="nav-links" aria-label="Primary">
{nav_links()}
      </nav>

      <a href="booking.html" class="btn btn-primary header-cta">Book Now</a>

      <button class="nav-toggle" aria-label="Toggle menu" aria-expanded="false">
        <svg class="icon"><use href="assets/icons/sprite.svg#icon-menu"></use></svg>
      </button>
    </div>

    <nav class="mobile-nav" aria-label="Mobile">
      <div class="container">
{nav_links(mobile=True)}
        <a href="booking.html" class="btn btn-primary">Book Now</a>
      </div>
    </nav>
  </header>
"""

def footer_html():
    return """  <footer class="site-footer">
    <div class="container footer-grid">
      <div class="footer-col">
        <img src="assets/images/logo.png" alt="Caribe Transfers VIP logo" width="48" height="48">
        <p>Private transportation, VIP chauffeur, and travel concierge across the Dominican Republic.</p>
      </div>

      <div class="footer-col">
        <h4>SERVICES</h4>
        <ul>
          <li><a href="services.html">Airport Transfers</a></li>
          <li><a href="services.html">Private Transportation</a></li>
          <li><a href="services.html">VIP Chauffeur</a></li>
          <li><a href="services.html">Corporate Transportation</a></li>
          <li><a href="services.html">Tourism &amp; Excursions</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>COMPANY</h4>
        <ul>
          <li><a href="about.html">About Us</a></li>
          <li><a href="index.html#faq">FAQ</a></li>
          <li><a href="contact.html">Contact</a></li>
          <li><a href="admin/login.php">Staff Login</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h4>CONTACT</h4>
        <ul>
          <li>support@caribetransfersvip.com</li>
          <li>+1 849-390-2963</li>
          <li>Santo Domingo, Dominican Republic</li>
        </ul>
      </div>
    </div>

    <div class="container footer-bottom">
      &copy; <span data-current-year></span> Caribe Transfers VIP. All rights reserved.
    </div>
  </footer>

  <a href="#" class="whatsapp-fab" data-whatsapp="Hello Caribe Transfers VIP, I'd like to book a transfer." aria-label="Chat on WhatsApp">
    <svg class="icon"><use href="assets/icons/sprite.svg#icon-whatsapp"></use></svg>
  </a>
"""

def scripts_html(extra=None):
    extra = extra or []
    lines = [
        '  <script src="js/validation.js"></script>',
        '  <script src="js/main.js"></script>',
    ]
    lines.extend(f'  <script src="js/{name}"></script>' for name in extra)
    return "\n".join(lines)

def page(title, description, canonical, body, extra_scripts=None):
    return (
        head(title, description, canonical)
        + "<body>\n"
        + header_html()
        + body
        + footer_html()
        + scripts_html(extra_scripts)
        + "\n</body>\n</html>\n"
    )

# ---------------------------------------------------------------------
# Page bodies are injected from placeholder files written alongside this
# script (index_body.html, about_body.html, etc.) so the HTML content
# itself stays easy to review/edit independently of this assembler.
# ---------------------------------------------------------------------
import os

PAGES = [
    ("index.html", "Caribe Transfers VIP | Private Transportation & Travel Concierge",
     "Private airport transfers, VIP chauffeur service, and travel concierge across the Dominican Republic.",
     "index.html", []),
    ("about.html", "About Us | Caribe Transfers VIP",
     "Learn about Caribe Transfers VIP, private transportation and concierge specialists in the Dominican Republic.",
     "about.html", []),
    ("services.html", "Services | Caribe Transfers VIP",
     "Airport transfers, private transportation, VIP chauffeur, corporate transportation and more.",
     "services.html", []),
    ("booking.html", "Book a Reservation | Caribe Transfers VIP",
     "Request your private transfer, VIP chauffeur, or concierge service in the Dominican Republic.",
     "booking.html", ["booking.js"]),
    ("contact.html", "Contact Us | Caribe Transfers VIP",
     "Get in touch with the Caribe Transfers VIP concierge team.",
     "contact.html", []),
]

if __name__ == "__main__":
    for filename, title, desc, canonical, extra_js in PAGES:
        body_file = filename.replace(".html", "_body.html")
        if not os.path.exists(body_file):
            print(f"skip {filename}: {body_file} not found")
            continue
        with open(body_file, encoding="utf-8") as f:
            body = f.read()
        html = page(title, desc, canonical, body, extra_js)
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)
        print("wrote", filename)
