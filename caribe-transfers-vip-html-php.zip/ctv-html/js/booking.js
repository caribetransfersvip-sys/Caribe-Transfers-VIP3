/* =========================================================================
   booking.js — booking form behavior: round-trip field toggle, validation,
   CSRF-protected submission to booking.php.
   ========================================================================= */

(function () {
  "use strict";

  var form = document.getElementById("booking-form");
  if (!form) return;

  /* Fetch a CSRF token (double-submit cookie pattern — see includes/csrf.php)
     before the user can submit. booking.php validates this against the
     ctv_csrf cookie set alongside it. */
  var csrfInput = document.getElementById("csrf_token");
  fetch("csrf-token.php", { credentials: "same-origin" })
    .then(function (res) { return res.json(); })
    .then(function (data) {
      if (csrfInput && data.token) csrfInput.value = data.token;
    })
    .catch(function () { /* form still submits; server rejects without a valid token */ });

  var roundTripCheckbox = form.querySelector('[name="is_round_trip"]');
  var roundTripFields = form.querySelector(".round-trip-fields");
  var statusPanel = document.getElementById("booking-status");
  var serverError = document.getElementById("booking-server-error");
  var submitBtn = form.querySelector('button[type="submit"]');

  function toggleRoundTrip() {
    if (!roundTripFields) return;
    var show = roundTripCheckbox && roundTripCheckbox.checked;
    roundTripFields.classList.toggle("is-visible", show);
    roundTripFields.querySelectorAll("input").forEach(function (input) {
      input.required = !!show;
    });
  }

  if (roundTripCheckbox) {
    roundTripCheckbox.addEventListener("change", toggleRoundTrip);
    toggleRoundTrip();
  }

  var rules = {
    service_type: { required: true },
    full_name: { required: true, minLength: 2 },
    email: { required: true, email: true },
    phone: { required: true, phone: true },
    pickup_location: { required: true, minLength: 2 },
    destination: { required: true, minLength: 2 },
    pickup_date: { required: true },
    pickup_time: { required: true },
    vehicle_type: { required: true }
  };

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (serverError) serverError.textContent = "";

    var result = CTVValidation.validateForm(form, rules);
    if (!result.valid) {
      var firstError = form.querySelector(".has-error");
      if (firstError) firstError.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    var formData = new FormData(form);

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending...";
    }

    fetch("booking.php", {
      method: "POST",
      body: formData,
      headers: { "X-Requested-With": "XMLHttpRequest" }
    })
      .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
      .then(function (result) {
        if (!result.ok || !result.data.success) {
          throw new Error((result.data && result.data.message) || "Request failed");
        }
        form.hidden = true;
        if (statusPanel) statusPanel.classList.add("is-visible");
      })
      .catch(function (err) {
        if (serverError) {
          serverError.textContent =
            "Something went wrong sending your request. Please try WhatsApp instead, or try again.";
        }
        console.error(err);
      })
      .finally(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Request Reservation";
        }
      });
  });
})();
