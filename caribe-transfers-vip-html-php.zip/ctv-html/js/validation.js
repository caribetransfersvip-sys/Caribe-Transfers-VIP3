/* =========================================================================
   validation.js — shared, dependency-free form validation helpers used
   by booking.js and the contact form on contact.html.
   ========================================================================= */

var CTVValidation = (function () {
  "use strict";

  function isEmpty(value) {
    return !value || String(value).trim().length === 0;
  }

  function isValidEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function isValidPhone(value) {
    var digits = String(value).replace(/\D/g, "");
    return digits.length >= 7;
  }

  // Applies/clears an error message on a .form-field wrapper.
  function setFieldError(fieldEl, message) {
    if (!fieldEl) return;
    var errorEl = fieldEl.querySelector(".field-error");
    if (message) {
      fieldEl.classList.add("has-error");
      if (errorEl) errorEl.textContent = message;
    } else {
      fieldEl.classList.remove("has-error");
      if (errorEl) errorEl.textContent = "";
    }
  }

  // Validates a <form> against a rules map:
  //   { fieldName: { required: true, email: true, phone: true, minLength: 2 } }
  // Field wrapper must be the input's closest .form-field and the input
  // must have name="fieldName". Returns { valid, values, errors }.
  function validateForm(form, rules) {
    var valid = true;
    var values = {};
    var errors = {};

    Object.keys(rules).forEach(function (name) {
      var input = form.querySelector('[name="' + name + '"]');
      if (!input) return;

      var fieldEl = input.closest(".form-field");
      var rule = rules[name];
      var value = input.type === "checkbox" ? input.checked : input.value;
      values[name] = value;

      var message = "";

      if (rule.required && (input.type === "checkbox" ? !value : isEmpty(value))) {
        message = rule.requiredMessage || "This field is required";
      } else if (rule.email && !isEmpty(value) && !isValidEmail(value)) {
        message = "Enter a valid email address";
      } else if (rule.phone && !isEmpty(value) && !isValidPhone(value)) {
        message = "Enter a valid phone number";
      } else if (rule.minLength && !isEmpty(value) && String(value).length < rule.minLength) {
        message = "Must be at least " + rule.minLength + " characters";
      }

      if (message) {
        valid = false;
        errors[name] = message;
      }
      setFieldError(fieldEl, message);
    });

    return { valid: valid, values: values, errors: errors };
  }

  function clearErrors(form) {
    form.querySelectorAll(".form-field.has-error").forEach(function (fieldEl) {
      setFieldError(fieldEl, "");
    });
  }

  return {
    isEmpty: isEmpty,
    isValidEmail: isValidEmail,
    isValidPhone: isValidPhone,
    setFieldError: setFieldError,
    validateForm: validateForm,
    clearErrors: clearErrors
  };
})();
