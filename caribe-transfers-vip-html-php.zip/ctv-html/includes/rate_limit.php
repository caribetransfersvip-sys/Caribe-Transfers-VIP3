<?php
/**
 * includes/rate_limit.php — very small session-based rate limiter for
 * public endpoints (booking.php, contact.php, admin login). Not a
 * substitute for server/CDN-level rate limiting, but stops naive spam
 * and brute-force loops on shared hosting where you may not control
 * nginx/Apache config.
 */

function rate_limit_check(string $key, int $maxAttempts, int $windowSeconds): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $now = time();
    $bucket = $_SESSION['rl_' . $key] ?? ['count' => 0, 'reset_at' => $now + $windowSeconds];

    if ($now > $bucket['reset_at']) {
        $bucket = ['count' => 0, 'reset_at' => $now + $windowSeconds];
    }

    $bucket['count']++;
    $_SESSION['rl_' . $key] = $bucket;

    return $bucket['count'] <= $maxAttempts;
}
