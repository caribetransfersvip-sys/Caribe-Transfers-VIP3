<?php
/**
 * includes/csrf.php — double-submit-cookie CSRF protection for the static
 * HTML front-end talking to PHP endpoints.
 *
 * Flow:
 *   1. csrf-token.php sets a random token as an httpOnly=false cookie
 *      (SameSite=Strict) AND returns the same token in a JSON body.
 *   2. The static page's JS puts that token in a hidden form field.
 *   3. On submit, booking.php / contact.php compare the posted token
 *      against the cookie — they must match. An attacker on another
 *      origin can't read the cookie value to forge the match.
 */

define('CSRF_COOKIE_NAME', 'ctv_csrf');

function csrf_issue_token(): string
{
    $token = bin2hex(random_bytes(32));
    setcookie(CSRF_COOKIE_NAME, $token, [
        'expires'  => time() + 3600,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => false, // JS needs to read it is NOT required here —
                              // token is also returned in the JSON body,
                              // so this can safely be true. Kept false only
                              // if you choose to read it via document.cookie
                              // instead of the JSON response.
        'samesite' => 'Strict',
    ]);
    return $token;
}

function csrf_validate(string $posted): bool
{
    if (empty($_COOKIE[CSRF_COOKIE_NAME]) || empty($posted)) {
        return false;
    }
    return hash_equals($_COOKIE[CSRF_COOKIE_NAME], $posted);
}
