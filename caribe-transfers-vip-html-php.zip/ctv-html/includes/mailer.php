<?php
/**
 * includes/mailer.php — thin wrapper around PHP's mail(). Hostinger
 * shared hosting supports mail() out of the box for the domain's own
 * mailboxes. For higher deliverability, swap send_email()'s body for
 * PHPMailer + SMTP (Hostinger also provides SMTP credentials for this).
 */

function send_email(string $to, string $subject, string $htmlBody): bool
{
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: Caribe Transfers VIP <" . FROM_EMAIL . ">\r\n";
    $headers .= "Reply-To: " . SUPPORT_EMAIL . "\r\n";

    return @mail($to, $subject, $htmlBody, $headers);
}
