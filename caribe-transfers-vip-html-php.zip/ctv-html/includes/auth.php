<?php
/**
 * includes/auth.php — session guard for admin/*.php pages.
 * Call require_admin() at the top of any protected page.
 */
require_once __DIR__ . '/../config.php';

function start_admin_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('ctv_admin_sess');
        session_start();
    }
}

function require_admin(): array
{
    start_admin_session();

    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }

    // Idle timeout: 30 minutes.
    if (!empty($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > 1800) {
        session_unset();
        session_destroy();
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();

    return [
        'id' => $_SESSION['admin_id'],
        'name' => $_SESSION['admin_name'],
        'role' => $_SESSION['admin_role'],
    ];
}

function csrf_admin_field(): string
{
    start_admin_session();
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf_token" value="' . $_SESSION['admin_csrf'] . '">';
}

function csrf_admin_validate(string $posted): bool
{
    return !empty($_SESSION['admin_csrf']) && hash_equals($_SESSION['admin_csrf'], $posted);
}
