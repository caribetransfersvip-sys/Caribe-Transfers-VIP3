<?php
/**
 * config.php — central configuration: database connection, session
 * hardening, and app constants. Included by every backend script.
 *
 * IMPORTANT: fill in real values before deploying, and keep this file
 * OUTSIDE any web-accessible directory if your Hostinger plan allows it,
 * or rely on the .htaccess rule in this project to block direct access.
 */

// ---- Environment ---------------------------------------------------
// On Hostinger, set these via the hPanel "Environment Variables" screen
// where available; otherwise edit the fallbacks below directly.
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'u123456789_ctv');
define('DB_USER', getenv('DB_USER') ?: 'u123456789_ctv');
define('DB_PASS', getenv('DB_PASS') ?: 'CHANGE_ME');

define('SITE_URL', getenv('SITE_URL') ?: 'https://caribetransfersvip.com');
define('SUPPORT_EMAIL', 'support@caribetransfersvip.com');
define('FROM_EMAIL', getenv('FROM_EMAIL') ?: 'no-reply@caribetransfersvip.com');

// ---- Session hardening ----------------------------------------------
ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_samesite', 'Strict');
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', '1');
}

// ---- Error handling ---------------------------------------------------
// Never display raw errors to visitors in production.
ini_set('display_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/logs/php-error.log');

// ---- Security headers (sent on every request that includes this file) --
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; frame-src https://www.google.com;");

// ---- Database connection (PDO, prepared statements everywhere) --------
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            error_log('DB connection failed: ' . $e->getMessage());
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Server error. Please try again later.']));
        }
    }
    return $pdo;
}

// ---- Small helpers used across handlers --------------------------------
function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function clean_input(string $value): string
{
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

function generate_booking_ref(): string
{
    return 'CTV-' . date('ym') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
}
