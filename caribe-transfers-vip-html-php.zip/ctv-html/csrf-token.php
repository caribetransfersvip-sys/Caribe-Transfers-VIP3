<?php
/**
 * csrf-token.php — called via fetch() from booking.js / the contact form
 * before the user submits. Issues a fresh CSRF token + cookie.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/csrf.php';

$token = csrf_issue_token();
json_response(['token' => $token]);
