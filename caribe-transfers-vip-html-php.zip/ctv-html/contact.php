<?php
/**
 * contact.php — handles the contact form on contact.html.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/rate_limit.php';
require_once __DIR__ . '/includes/mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Method not allowed'], 405);
}

if (!rate_limit_check('contact', 10, 300)) {
    json_response(['success' => false, 'message' => 'Too many requests. Please try again shortly.'], 429);
}

if (!csrf_validate($_POST['csrf_token'] ?? '')) {
    json_response(['success' => false, 'message' => 'Invalid or expired form session. Please refresh and try again.'], 403);
}

$name = clean_input($_POST['name'] ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$message = clean_input($_POST['message'] ?? '');

$errors = [];
if (mb_strlen($name) < 2) $errors[] = 'Name is required';
if (!$email) $errors[] = 'A valid email is required';
if (mb_strlen($message) < 5) $errors[] = 'Message is too short';
if (mb_strlen($message) > 2000) $message = mb_substr($message, 0, 2000);

if (!empty($errors)) {
    json_response(['success' => false, 'message' => implode(' ', $errors)], 400);
}

try {
    $pdo = db();
    $stmt = $pdo->prepare(
        'INSERT INTO contact_messages (name, email, message, created_at) VALUES (:name, :email, :message, NOW())'
    );
    $stmt->execute(['name' => $name, 'email' => $email, 'message' => $message]);
} catch (Throwable $e) {
    error_log('Contact insert failed: ' . $e->getMessage());
    json_response(['success' => false, 'message' => 'Could not send your message. Please try again.'], 500);
}

send_email(
    SUPPORT_EMAIL,
    'New contact form message from ' . $name,
    "<p><strong>From:</strong> " . htmlspecialchars($name) . " ({$email})</p><p>" . nl2br(htmlspecialchars($message)) . "</p>"
);

json_response(['success' => true], 201);
