# Caribe Transfers VIP — Static HTML/CSS/JS + PHP/MySQL Edition

A full conversion of the Next.js/React/Tailwind/Supabase build into plain
HTML5, CSS3, vanilla JavaScript, and PHP 8 + MySQL — no Node, no build step,
no Vercel/Supabase account required. Uploads directly to Hostinger shared
hosting via File Manager or FTP.

## Folder structure
```
/
├── index.html, about.html, services.html, booking.html, contact.html
├── css/style.css, css/responsive.css, css/animations.css
├── js/main.js, js/booking.js, js/validation.js
├── assets/images/logo.png, assets/icons/sprite.svg
├── config.php               ← DB connection + security headers
├── csrf-token.php           ← issues CSRF tokens for the public forms
├── booking.php               ← handles the booking form
├── contact.php                ← handles the contact form
├── database.sql              ← full MySQL schema
├── includes/
│   ├── csrf.php, rate_limit.php, mailer.php, auth.php
├── admin/
│   ├── login.php, logout.php, dashboard.php, create-admin.php
│   ├── reservations.php, clients.php, drivers.php, vehicles.php,
│   │   payments.php, reports.php, settings.php
├── .htaccess, robots.txt, sitemap.xml
```

## 1. Deploy to Hostinger
1. Log into **hPanel** → File Manager (or an FTP client) → open `public_html`.
2. Upload every file/folder in this project into `public_html` (keep the structure above).
3. In **hPanel → Databases → MySQL Databases**, create a database + user, and note the host/name/user/password.
4. Open **phpMyAdmin** (linked from the same page), select your new database, go to **Import**, and upload `database.sql`.

## 2. Configure
Open `config.php` and set your real database credentials (or set them as
environment variables in hPanel if your plan supports it):
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u123456789_ctv');
define('DB_USER', 'u123456789_ctv');
define('DB_PASS', 'your-real-password');
```
Also update `SITE_URL` and `FROM_EMAIL` to your real domain.

## 3. Create your first admin account
Never hardcode a password hash. Run the one-time script instead:

**With SSH/Terminal access (hPanel → Advanced → SSH Access, if included in your plan):**
```bash
php admin/create-admin.php "Your Name" "you@example.com" "a-strong-password"
```

**Without shell access**, visit once in your browser (replace with your values, URL-encode as needed):
```
https://yourdomain.com/admin/create-admin.php?name=Your+Name&email=you@example.com&password=a-strong-password
```
**Then delete `admin/create-admin.php` immediately** — leaving it live lets anyone create an admin account.

Log in at `https://yourdomain.com/admin/login.php`.

## 4. Email delivery
`includes/mailer.php` uses PHP's built-in `mail()`, which works out of the
box on Hostinger for your domain's own addresses. For better deliverability,
swap it for PHPMailer + Hostinger's SMTP credentials (hPanel → Emails).

## Security checklist (already implemented)
- **Password hashing**: `password_hash()` / `password_verify()` (bcrypt).
- **SQL injection protection**: every query uses PDO prepared statements.
- **CSRF protection**: double-submit cookie pattern for public forms
  (`csrf-token.php` + `includes/csrf.php`), session token for admin forms.
- **XSS protection**: all output escaped with `htmlspecialchars()`; a
  Content-Security-Policy header is sent from `config.php`.
- **Rate limiting**: session-based limiter on booking, contact, and admin
  login (`includes/rate_limit.php`).
- **Session hardening**: `httponly`, `SameSite=Strict`, secure-when-HTTPS
  cookies, 30-minute idle timeout, `session_regenerate_id()` on login.
- **File protection**: `.htaccess` denies direct access to `config.php`,
  `database.sql`, and the whole `includes/` folder.
- **Security headers**: X-Frame-Options, X-Content-Type-Options,
  Referrer-Policy, CSP — set globally in `config.php`.

## What's a full build vs. a skeleton
- **Fully wired**: public site (all 5 pages), booking flow end-to-end,
  contact form, admin login/logout/session guard, dashboard with live
  stats + reservations table.
- **Skeleton (listing view wired, CRUD to add)**: `admin/clients.php`,
  `drivers.php`, `vehicles.php`, `payments.php`, `settings.php` render a
  live table from MySQL but don't yet have Create/Edit/Delete forms —
  copy the prepared-statement pattern in `booking.php` to add them.
- **Not included**: Stripe/PayPal checkout (needs your live API keys),
  transactional email via SMTP (currently uses PHP `mail()`).

## Local preview (optional, for testing before upload)
```bash
php -S localhost:8000
```
Then open `http://localhost:8000/index.html`. The booking/contact forms
need a real MySQL connection to fully work — point `config.php` at a local
MySQL instance with `database.sql` imported, or a free XAMPP/MAMP setup.

## `dev-source/` folder
Contains the Python assembly script and per-page HTML partials used to
generate the five root `.html` files (keeps the shared header/nav/footer
consistent across pages when editing). **Not needed on the live server** —
skip uploading this folder, or delete it after upload. If you want to edit
shared markup (nav links, footer), edit the partials here and re-run
`python3 build_pages.py`, or just hand-edit the five root HTML files
directly — they're plain static HTML either way.

